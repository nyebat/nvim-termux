import java.util.Scanner

fun getInput(msg: String): String {
    print(msg)
    System.out.flush()
    val scanner = Scanner(System.`in`)
    return scanner.nextLine().trim()
}

fun pushProduk(produk: MutableList<String>, prompt: String) {
    val addElement = getInput("$prompt Nama elemen : ")
    if (!produk.contains(addElement)) {
        produk.add(addElement)
    } else {
        println("Err! Elemen '$addElement' sudah ada!")
    }
}

fun removeProduk(produk: MutableList<String>, prompt: String) {
    val rmElement = getInput("$prompt Nama elemen : ")
    val index = produk.indexOfFirst { it == rmElement }
    if (index != -1) {
        produk.removeAt(index)
    } else {
        println("Err! Elemen '$rmElement' tidak ditemukan!")
    }
}

fun editProduk(produk: MutableList<String>, prompt: String) {
    val source = getInput("$prompt Elemen sumber : ")
    val index = produk.indexOfFirst { it == source }
    if (index != -1) {
        val newValue = getInput("$prompt Ubah ke : ")
        if (produk.contains(newValue)) {
            println("Elemen dengan nama yang sama sudah ada!")
            return
        }
        produk[index] = newValue
        println("Elemen '$source' diubah menjadi $newValue!")
    } else {
        println("Err! Elemen '$source' tidak ditemukan!")
    }
}

fun printProdukMenu(produk: List<String>) {
    println()
    for ((index, value) in produk.withIndex()) {
        println("$index | $value")
    }
    println()
}

fun printEditorMenu(editor: List<String>) {
    for ((index, value) in editor.withIndex()) {
        if (index == 0) print("Editor: ")
        print(value)
        if (index < editor.size - 1) print(" | ")
    }
}

fun addListProduk() {
    val produk = mutableListOf("C++", "Java", "Rust", "Kotlin")
    val editor = listOf("[e]dit", "[p]ush", "[r]emove", "[q]uit")

    while (true) {
        printProdukMenu(produk)
        printEditorMenu(editor)

        val input = getInput("\n\$~ : ")

        when (input.lowercase()) {
            "q" -> break
            "e" -> editProduk(produk, "\n[e]dit > ")
            "p" -> pushProduk(produk, "\n\$ [P]ush > ")
            "r" -> removeProduk(produk, "\n\$ [R]emove > ")
            else -> println("Err! Input tidak valid! '$input' Tidak ditemukan dalam menu lingkup.")
        }
    }

    println("\nTERIMA KASIH.")
}

fun main() {
    addListProduk()
}

