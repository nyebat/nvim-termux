import java.util.List;
import java.util.ArrayList;


public class ifElse {
    /**
     * ifelse
     */

    public static void main(String args[]) {
        int a = 10;
        int b = 12;

        if (a + b > 20) {
            System.out.println("is true");
        } else { 
            System.out.println("is false");
        }

        List<String> kolektif = new ArrayList<>();
        kolektif.add("Java");
        kolektif.add("C++");
        kolektif.add("Rust");

        int istrue = kolektif.indexOf("C++");
        if (istrue != -1) {
            System.out.println(istrue);
        } else {
            System.out.println(istrue);
        }
    }
}
