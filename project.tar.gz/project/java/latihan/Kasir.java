import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Kasir {

    public static String getInput(String msg) {
        System.out.print(msg);
        System.out.flush();
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine().trim();
    }

    public static void pushProduk(List<String> produk, String prompt) {
        String addElement = getInput(prompt + " Nama elemen : ");
        if (!produk.contains(addElement)) {
            produk.add(addElement);
        } else {
            System.out.println("Err! Elemen '" + addElement + "' sudah ada!");
        }
    }

    public static void remvProduk(List<String> produk, String prompt) {
        String rmElement = getInput(prompt + " Nama elemen : ");
        int index = produk.indexOf(rmElement);
        if (index != -1) {
            produk.remove(index);
        } else {
            System.out.println("Err! Elemen '" + rmElement + "' tidak ditemukan!");
        }
    }

    public static void editProduk(List<String> produk, String prompt) {
        String source = getInput(prompt + " Elemen sumber : ");
        int index = produk.indexOf(source);
        if (index != -1) {
            String newValue = getInput(prompt + " Ubah ke : ");
            if (produk.contains(newValue)) {
                System.out.println("Elemen dengan nama yang sama sudah ada!");
                return;
            }
            produk.set(index, newValue);
            System.out.println("Elemen '" + source + "' diubah menjadi " + newValue + "!");
        } else {
            System.out.println("Err! Elemen '" + source + "' tidak ditemukan!");
        }
    }

    public static void printProdukMenu(List<String> produk) {
        System.out.println();
        for (int i = 0; i < produk.size(); i++) {
            System.out.println(i + " | " + produk.get(i));
        }
        System.out.println();
    }

    public static void printEditorMenu(List<String> editor) {
        System.out.print("Editor: ");
        for (int i = 0; i < editor.size(); i++) {
            System.out.print(editor.get(i));
            if (i < editor.size() - 1) {
                System.out.print(" | ");
            }
        }
        System.out.println();
    }

    public static void addListProduk() {
        List<String> produk = new ArrayList<>();
        produk.add("Kusen");
        produk.add("Jendela");
        produk.add("Pintu");

        List<String> editor = new ArrayList<>();
        editor.add("[e]dit");
        editor.add("[p]ush");
        editor.add("[r]emove");
        editor.add("[q]uit");

        while (true) {
            printProdukMenu(produk);
            printEditorMenu(editor);

            String input = getInput("\n$~ : ").toLowerCase();

            switch (input) {
                case "q":
                    return;
                case "e":
                    editProduk(produk, "\n[e]dit > ");
                    break;
                case "p":
                    pushProduk(produk, "\n$ [P]ush > ");
                    break;
                case "r":
                    remvProduk(produk, "\n$ [R]emove > ");
                    break;
                default:
                    System.out.println("Err! Input tidak valid! '" + input + "' Tidak ditemukan dalam menu lingkup.");
            }
        }

    }

    public static void main(String[] args) {
        addListProduk();
        System.out.println("\nTERIMA KASIH.");
    }
}

