#include <cstdio>
// #include <iostream>

float operasi(float a, float b, char opt) {
    float result;
    switch (opt) {
        case '-': result = a - b; break;
        case '+': result = a + b; break;
    }

    return result;
}

int main () {
    int data[] = {10,11,12,13,14,15,16,17,18,19,20};
    int cariNilai;
    bool ketemu {false};

    printf("Masukkan nilai yg dicari: ");
    scanf("%i", &cariNilai);

    for (int i=0; i < 11; i++) {
        if (cariNilai == data[i]) {
            printf("Nilai %i ditemukan pada index ke-%i\n", cariNilai, i);
            ketemu = true;
            break;
        }
    }

    for (int c : data) { printf("%i\n", c); }

    if (!ketemu) {
        printf("Nilai %i tidak ditemukan\n", cariNilai);
    } 

    char opt = 't';
    printf("\n%.1f",operasi(10, 3, opt));

    return 0;
}
