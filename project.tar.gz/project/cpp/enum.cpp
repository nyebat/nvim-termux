#include <iostream>

struct Unit { int harga; int qtty; };
enum Produk { kusen, pintu, jendela };

void show(Unit &unit, Produk produk) {
  switch (produk) {
    case kusen: unit.harga = 2000; unit.qtty = 2; break;
    case pintu: unit.harga = 7000; unit.qtty = 7; break;
    case jendela: unit.harga = 1200; unit.qtty = 12; break;
  }

  std::cout << " harga: " << unit.harga << " qtty: " << unit.qtty << std::endl;
}

int main () {
  Unit unit;
  unit.harga = 1200;
  unit.qtty = 3;

  show(unit, Produk::jendela);
  show(unit, Produk::pintu);
  show(unit, Produk::kusen);

  return 0;
}
