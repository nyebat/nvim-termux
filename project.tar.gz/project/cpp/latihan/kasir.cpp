#include <iostream>
#include <vector>
#include <string>

std::string getinput(const std::string& msg) {
    std::string input;
    std::cout << msg;
    std::cout.flush();
    std::getline(std::cin, input);
    return input;
}

void push_produk(std::vector<std::string>& produk, const std::string& promp) {
    std::string add_element = getinput(promp + "Nama element : ");

    bool status = false;
    for (const auto& i : produk) {
        if (i == add_element) {
            status = true;
            std::cout << "Err! Element '" << add_element << "' sudah ada!" << std::endl;
        }
    }

    if (!status) {
        produk.push_back(add_element);
    }
}

void remv_produk(std::vector<std::string>& produk, const std::string& promp) {
    std::string rm_element = getinput(promp + "Nama element : ");

    std::vector<std::string> produk_clone = produk;
    bool status = false;

    for (size_t i = 0; i < produk_clone.size(); ++i) {
        if (produk_clone[i] == rm_element) {
            produk.erase(produk.begin() + i);
            status = true;
        }
    }

    if (!status) {
        std::cout << "Err! Element '" << rm_element << "' tidak ditemukan!" << std::endl;
    }
}

void edit_produk(std::vector<std::string>& produk, const std::string& promp) {
    std::string source = getinput(promp + "Source element : ");

    bool status = false;

    for (size_t i = 0; i < produk.size(); ++i) {
        if (produk[i] == source) {
            status = true;
            produk[i] = getinput(promp + "Change to : ");
            std::cout << "Element '" << source << "' edited to " << produk[i] << "!" << std::endl;
        }
    }

    if (!status) {
        std::cout << "Err! Element '" << source << "' tidak ditemukan!" << std::endl;
    }
}

template <typename T>
void print_menu(const std::vector<T>& items) {
    std::cout << std::endl;
    for (size_t i = 0; i < items.size(); ++i) {
        std::cout << i << " | " << items[i] << std::endl;
    }
    std::cout << std::endl;
}

void add_list_produk() {
    std::vector<std::string> produk = { "Kusen", "Jendela", "Pintu" };
    std::vector<std::string> editor = { "[e]dit", "[p]ush", "[r]emove", "[q]uit" };

    std::string promp = "\n$~ : ";

    while (true) {
        print_menu(produk);
        // print_menu(editor);
        for (int i; i < editor.size(); i++ ) {
            if (i == 0) std::cout << "Menu: ";
            std::cout << editor[i] << " ";
        }

        std::string input = getinput(promp);

        if (input == "q" || input == "Q") {
            break;
        } else if (input == "e" || input == "E") {
            edit_produk(produk, "\n[e]dit > ");
        } else if (input == "p" || input == "P") {
            push_produk(produk, "\n$ [P]ush > ");
        } else if (input == "r" || input == "R") {
            remv_produk(produk, "\n$ [R]emove > ");
        } else {
            std::cout << "Err! Input is invalid! '" << input << "' Not found in the scope menu." << std::endl;
        }
    }

    std::cout << "\nTERIMA KASIH." << std::endl;
}

int main() {
    add_list_produk();
    return 0;
}

