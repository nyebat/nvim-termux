#include <iostream>
using namespace std;

//mendapatkan karakter digit
int getAngka(string value){
  string temp;
  for(char c : value){
    if(isdigit(c)) temp += c;
  }
  return stoi(temp);
}

//mendapatkan karakter huruf
string getHuruf(string value){
  string temp;
  for(char c : value){
    if(isalpha(c)) temp += c;
  }
  return temp;
}

//mendapatkan karakter selain huruf dan angka
string getSimbol(string value){
  string temp;
  for(char c : value){
    if(!isalnum(c)) temp += c;
  }
  return temp;
}

//mendapatkan karakter sebelum simbol'-'
string sebelumMinus(string value){
  return value.substr(0, value.find(getSimbol(value)));
}

//mendapatkan karakter sesudah simbol'-'
string sesudahMinus(string value){
  return value.substr(value.find(getSimbol(value)) + 1);
}

//mencetak semua simbol pada ASCII
string simbolAscii(){
  string temp;
  for(char c{' '}; c < '~'; c++){ temp += c;}
  return temp;
}

int main(){
  string value = "smk-kelas12";
  cout << "string yg di olah  : " << value << "\n\n";
  cout << "angka  : " << getAngka(value) << endl;
  cout << "huruf  : " << getHuruf(value) << endl;
  cout << "simbol : " << getSimbol(value) << endl;
  cout << "sebelum simbol : " << sebelumMinus(value) << endl;
  cout << "sesudah simbol : " << sesudahMinus(value) << endl;
  cout << endl;

  cout << simbolAscii() << endl << endl;
  cout << getAngka(simbolAscii()) << endl;
}
