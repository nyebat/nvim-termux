#include <iostream>

int main (int argc, char *argv[])
{
	unsigned int pin;
	unsigned short jumlah {0U};

	do {
		std::cout << "Masukan PIN: ";
		std::cin >> pin;
		jumlah++;
		if (pin != 123456U && jumlah == 1) {
			std::cout << "PIN yang Anda masukan salah!\n" << std::endl;
		} else if(pin != 123456U && jumlah == 2) {
			std::cout << "Hati-hati, Anda sudah 2x salah memasukan PIN.\n" << std::endl;
		}

	} while (jumlah < 3 && pin != 123456U);

	if (pin != 123456U) {
		std::cout << "Anda sudah salah 3x memasukan PIN. Akun diblokir!" << std::endl;
		exit(1);
	}

	std::cout << "\nSelamat, Anda berhasil login." << std::endl;
	return 0;
}
