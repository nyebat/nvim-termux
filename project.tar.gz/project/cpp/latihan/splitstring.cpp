#include <iostream>
#include <vector>
#include <sstream>

std::vector<std::string> splitString(std::string str, char delimiter) {
    std::vector<std::string> result;
    std::stringstream ss(str);
    std::string token;

    while (std::getline(ss, token, delimiter)) {
        result.push_back(token);
    }

    return result;
}

int main() {
    std::string sentence = "The quick brown fox jumps over the lazy dog.";
    char delimiter = ' ';

    std::vector<std::string> words = splitString(sentence, delimiter);

    for (auto word : words) {
        std::cout << word << std::endl;
    }

    return 0;
}

