#include <iostream>
using namespace std;

string myStr(){
  return {"Tiara menggamit kenangan zaman persekolahan \
Tiara kumimpi kita bersanding atas kayangan \
Seakan bisa kusentuh peristiwa semalam \
Di malam pesta engkau bisikkan kata azimat di telinga \
Kita terpaksa berpisah untuk mencari arah \
Kita dipukul ombak hidup alam yang nyata \
Engkau jauh meniti puncak menara gading \
Yang menjanjikan hidup sempurna \
Tapi aku hanya tunduk ke bumi hidup tertekan \
Jika kau bertemu aku begini \
Berlumpur tubuh dan keringat membasah bumi \
Di penjara terkurung terhukum Hanya bertemankan sepi \
Bisakah kau menghargai Cintaku yang suci ini \
Oh Tiara pedihnya Dapatkah kau merasakan \
Oh Tiara pedihnya dapatkah kau merasakan \
Jika kau bertemu aku begini \
Berlumpur tubuh dan keringat membasah bumi \
Di penjara terkurung terhukum Hanya bertemankan sepi \
Bisakah kau menghargai cintaku yang suci ini \
Oh Tiara pedihnya dapatkah kau merasakan \
Oh Tiara pedihnya dapatkah kau merasakan"};
}

int main() {
  string str = "my name: ";

  string value = myStr();
  unsigned short jumlahKata {1};

  for (char c : value) { if (c == ' ') jumlahKata++; }

  string kata[jumlahKata];
  unsigned short posisiSpasi {0};

  for (int i = 0; i < jumlahKata; i++) {
    posisiSpasi = value.find(' ');

    if(posisiSpasi > 0) {
      kata[i] = value.substr(0, posisiSpasi);
      value.erase(0, posisiSpasi +1);
    } else { kata[i] = value; }
  }

  unsigned short index {0};
  do {
    cout << "Jumlah kata dalam string: " << jumlahKata << endl;
    cout << "Tampilkan kata ke? : "; cin >> index;

    system ("clear");

    if(index > 0 && index <= jumlahKata) {
      cout << "\nKata ke-" << index << " = \'" << kata[index -1] << "\'\n\n";
    } else { exit(1); }
  } while (index > 0 && index <= jumlahKata);

  return 0;
}
