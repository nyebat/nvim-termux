#include<iostream>
using namespace std;

//operasi penjumlahan
void tambah(float angka1, float angka2){
	cout << angka1 + angka2 << '\n';
}
//operasi pengurangan
void kurang(float angka1, float angka2){
	cout << angka1 - angka2 << '\n';
}
//operasi perkalian
void kali(float angka1, float angka2){
	cout << angka1 * angka2 << '\n';
}
//operasi pembgian
void bagi(float angka1, float angka2){
	cout << angka1 / angka2 << '\n';
}
//mendapatkan inputan user
float getUserInput(string pesan){
	float input;
	bool isInputValid = false;
	do{
  	cout << pesan;
	  cin >> input;
	  // memeriksa inputan user
	  if(cin.fail()){
		  isInputValid = false;
		  cin.clear();
		  cin.ignore(numeric_limits<streamsize>::max(), '\n');
		  pesan = "input invalid! : ";
	  }else{
		  isInputValid = true;
	  }
	}while(!isInputValid);
	
	return input;
}
//menentukan operasi berdasarkan operator yg dipilih
void operasi(char operatorTerpilih, float angka1, float angka2){
	switch(operatorTerpilih){
	case '+':
		tambah(angka1, angka2);
		break;
	case '-':
		kurang(angka1, angka2);
		break;
	case '*':
		kali(angka1, angka2);
		break;
	case '/':
		bagi(angka1, angka2);
		break;
	}
}

int main(){
	char operatorTerpilih;
	cout << "Simpel Kalkulator : \n";
	//loop memilih operator matematika
	do{
		cout << " [+] penjumlahan\n";
		cout << " [-] Pengurangan\n";
		cout << " [*] Perkalian\n";
		cout << " [/] Pembagian\n";
		cout << "Pilih Operator : ";
		cin >> operatorTerpilih;
	}while( operatorTerpilih != '+' 
				& operatorTerpilih != '-' 
				& operatorTerpilih != '*'
				& operatorTerpilih != '/'
	);
	//menyimpan inputan user ke variabel baru
	float angka1 = getUserInput("Masukkan Angka Pertama : ");
	float angka2 = getUserInput("Masukkan Angka kedua   : ");
	//menjalankan operasi
	operasi(operatorTerpilih, angka1, angka2);
	
	return 0;
}

