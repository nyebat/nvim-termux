#include<iostream>
using namespace std;

int jumlah_spasi(string value){
  unsigned short temp{0};
  for (char c : value){ if(c == ' ' | c == '\t') temp++; }
  return temp;
}

int jumlah_kata(string value){
  int temp{1};
  // for (char c : value){ if(c == ' ' | c == '\t') temp++; }
  for (char c : value) { if (c == ' ' | c == '\t') temp++; }
  return temp;
}

int main(){
  int d;
  string kalimat="aa bb cc dd";
  cout << kalimat << endl;
  cout << "jumlah spasi : " << jumlah_spasi(kalimat) << endl;
  cout << "jumlah kata  : " << jumlah_kata(kalimat) << endl;

  return 0;
}
