#include <iostream>
using namespace std;

int angka(string value){
	string tmp;
	for(char c : value) {
		if(isdigit(c)) tmp += c;
	}
	return stoi(tmp);
}

string huruf(string value){
	string tmp;
	for(char c : value){
		if(isalpha(c)) tmp += c;
	}
	return tmp;
}

char simbol(string value){
	char tmp;
	for(char c : value){
		if(!isalnum(c)) tmp += c;
	}
	return tmp;
}

string sebelumMinus(string value){
	return value.substr(0, value.find('-'));
}

string sesudahMinus(string value){
	return value.substr(value.find('-') + 1);
}

int main (){
	string value{"kelas12-SMK"};
	
	cout << "string = " << value << endl;

	cout << "get digit : " << angka(value) << endl;
	cout << "get huruf : " << huruf(value) << endl;
	cout << "get simbol: " << simbol(value) << endl;
	cout << "get sebelum minus : " << sebelumMinus(value) << endl;
	cout << "get sesudah minus : " << sesudahMinus(value) << endl;
	
	return 0;
}
