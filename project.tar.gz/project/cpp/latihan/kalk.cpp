#include <iostream>
//using namespace std;

int main () {
  std::cout << "Masukkan angka: ";

  int angka;
  std::cin >> angka;
  std::cout << angka << '\n';
}
