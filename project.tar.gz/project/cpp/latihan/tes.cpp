#include <iostream>

void f(int &value) {
    std::cout << "value sebelum diubah: " << value << " " << &value << std::endl;

    value++;
    std::cout << "value setelah diubah: " << value << " " << &value << std::endl;
}

int main () {
    int b {5};
    std::cout << "reference b: " << &b << std::endl;

    f(b);
    std::cout << "\nNilai b setelah pemanggilan f(): " << b << std::endl;
    std::cout << "reference b: " << &b << std::endl;
    return 0;
}
