#include <iostream>
#include <sstream>
#include <vector>

std::string myStr(){
	const std::string value {
		"Tiara menggamit kenangan zaman persekolahan \
		Tiara kumimpi kita bersanding atas kayangan \
		Seakan bisa kusentuh peristiwa semalam \
		Di malam pesta engkau bisikkan kata azimat di telinga \
		Kita terpaksa berpisah untuk mencari arah \
		Kita dipukul ombak hidup alam yang nyata \
		Engkau jauh meniti puncak menara gading \
		Yang menjanjikan hidup sempurna \
		Tapi aku hanya tunduk ke bumi hidup tertekan \
		Jika kau bertemu aku begini \
		Berlumpur tubuh dan keringat membasah bumi \
		Di penjara terkurung terhukum Hanya bertemankan sepi \
		Bisakah kau menghargai Cintaku yang suci ini \
		Oh Tiara pedihnya Dapatkah kau merasakan \
		Oh Tiara pedihnya dapatkah kau merasakan \
		Jika kau bertemu aku begini \
		Berlumpur tubuh dan keringat membasah bumi \
		Di penjara terkurung terhukum Hanya bertemankan sepi \
		Bisakah kau menghargai cintaku yang suci ini \
		Oh Tiara pedihnya dapatkah kau merasakan \
		Oh Tiara pedihnya dapatkah kau merasakan"
	};

	return value;
}

std::vector <std::string> getKata() {
	std::vector <std::string> teks;
	std::string kata;
	std::istringstream iss(myStr());

	while (iss >> kata) {
		teks.push_back(kata);
	}

	return teks;
}

int main() {
	std::vector <std::string> kata = getKata();
	unsigned short index {1};
	unsigned short jumlahKata = kata.size();
	
	while (index > 0 && index <= jumlahKata) {
		std::cout << "\n\nJumlah kata : " << jumlahKata
			<< "\nTampilkan kata ke? : ";
		std::cin >> index;
		
		system("clear");
		
		if (index > 0 && index <= jumlahKata) {
			std::cout << "Kata ke-" << index << " = \'"
			<< kata[index -1] << "\'";
		}
	}

	return 0;
}
