#include <iostream>

int main () {
    int n, i;

    std::cout << "masukkan nilai n: ";
    std::cin >> n;

    //contoh 1:
    i = 1;
    while (i <= n) { 
        std::cout << i << " "; 
        i++;
        if (i == n +1) std::cout << "\n";
    }

    // contoh 2: menampilkan terbalik
    i = 1;
    while (n >= i) { 
        std::cout << n << " "; 
        n--;
        if (n == i -1) std::cout << "\n\n";
    }

    //contoh 3: mengiterasi array
    int data[5] = {
        1000,2000,3000,4000,5000
    };

    i = 0;
    while (i < 5) {
        std::cout << "Element ke-" << i << ": " << data[i] << "\n";
        i++;
    }

    std::cout << "\n";

    // contoh 4: while tanpa index
    int a, b;

    std::cout << "Program pembagian bilangan bulat\n";
    std::cout << "masukkan nilai a: "; std::cin >> a;
    std::cout << "masukkan nilai b: "; std::cin >> b;

    std::cout << "\n" << a << " % " << b << " = ";

    //menghitung sisa bagi dari a/b
    while (a >= b) a -= b;

    std::cout << a << std::endl;
    return 0;
}
