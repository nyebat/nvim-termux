extern crate mymod;
use mymod::{getinput::{get_alpha, get_number}, sum::sum};

fn main() {
    let mut iterasi: u8 = 1;
    loop {
        if iterasi == 3 {
            iterasi = 0
        } else if iterasi == 1 {
            println!(
                "\nSIMPEL KALKULATOR\n\n\t\
                [+] Penjumlahan\t[-] Pengurangan\n\t\
                [*] Perkalian\t[/] Pembagian\n\t\
                [0] EXIT"
            )
        }

        iterasi += 1;
        let operator: &str = &get_alpha("\nselect: ");

        if operator == "+" || operator == "-" || operator == "*" || operator == "/" {
            let (value1, value2): (f64, f64) = (
                get_number(get_alpha("bilangan pertama : ")),
                get_number(get_alpha("bilangan kedua   : "))
            );

            let result: f64 = sum(&value1, &value2, &operator);
            println!("\nHasil {value1} {operator} {value2} = {}", &result)
        } else if operator == "0" {
            break
        } else {
            println!("menu invalid")
        }
    }
}
