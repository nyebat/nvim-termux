/*
VecDeque<T>
Tipe data VecDeque<T> adalah sama seperti Vec<T> plus mendukung operasi menambah dan mengurangi elemen dari dua sisi secara efisien.

Pada tipe data Vec<T>, ada method pop yang fungsinya menghapus data elemen terakhir dan method push untuk menambah elemen baru dari kanan. Tipe data VecDeque memiliki bebebrapa method tambahan, yaitu:

method pop_front untuk hapus data elemen pertama atau paling kiri (indeks ke-0)
method push_front untuk menambah data dari kiri (indeks ke-0)
method pop_back untuk hapus data elemen pertama atau paling kanan (indeks terakhir)
method push_back untuk menambah data dari kanan (indeks terakhir)
Contoh penerapan:
*/

use std::collections::VecDeque;

fn main() {
    let mut vec_10 = VecDeque::from(
        vec![
            "apel",
            "mangga",
            "jeruk",
        ]
    );
    println!("data awal: {:?}", vec_10);
    
    vec_10.pop_front(); // menghapus element pertama
    println!("pop front: {:?}", vec_10);

    vec_10.push_front("ayam"); // menambahkan elemen ke index pertama
    println!("push front: {:?}", vec_10);

    vec_10.pop_back();
    println!("pop back: {:?}", vec_10);

    vec_10.push_back("bebek");
    println!("push back: {:?}\n", vec_10);
}
