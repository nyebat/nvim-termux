fn main() {
    // closure that prints a text
    let print_text = || println!("Hello, World!");
    print_text(); 

    // closure dengan parameter
    let add = |x:i32| x + x;
    let result = add(2);
    println!("add: {}", result);

    // closure multyline
    let tambah_kali = |x:i32, y:i32| {
        let tambah = x + y;
        let kali = tambah * tambah;
        let hasil = kali - tambah;
        return hasil;
    };

    let hasil_operasi = tambah_kali(2,3);
    println!("tambah_kali: {}", hasil_operasi);

    //scope closure
    let number = 100;
    let closure_scope = || println!("closure_scope: {}", number);
    closure_scope();


    // 1.variabel tidak dimodifikasi didalam closure
    let word = String::from("Hello");
    // immutable closure
    let print_str = || { println!("word = {}", word); };
    // immutable borrow is possible outside the closure
    println!("length of word = {}", word.len());
    print_str();

    // 2. variabel dimodifikasi didalam penutupan
    let mut word = String::from("Hello");
    // mutable closure
    let mut print_str = || {
        // value of word is changed here
        word.push_str(" World!");
        println!("word = {}", word);
    };
     
     // cannot immutable borrow because the variable is borrowed as mutable inside the closure
     // println!("length of word = {}", word.len());
    
    print_str();

    // can immutable borrow because the closure has been already used
    println!("length of word = {}", word.len());


    // 3. variabel dipindahkan didalam closure
    let word = String::from("Hello");

    // immutable closure
    let print_str = || {
        // word variable is moved to a new variable
        let new_word = word;
        println!("word = {}", new_word);
    };

    print_str();

    // cannot immutable borrow because word variable has moved inside closure
    // println!("length of word = {}", word.len());

    // Closure sebagai parameter function
    let args = |x:i32| x;
    let result = closure_args(5, args);
    println!("result: {}", result);
}

fn closure_args <F: Fn(i32) -> i32> ( x:i32, f: F ) -> i32 {
    f(x) + 2
}

