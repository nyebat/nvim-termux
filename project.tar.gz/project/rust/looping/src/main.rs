fn main() {
    use std::io::{self, Write};

    let getinput = |msg: &'static str| -> i32 {
        loop {
            print!("{}", msg);
            io::stdout().flush().unwrap();

            let mut input = String::new();
            io::stdin().read_line(&mut input).expect("stdin Err!");

            if let Ok(c) = input.trim().parse::<i32>() {break c;}
        }
    };

    let input = getinput("Masukkan nilai n: ");
    let mut i = 1;
    loop {
        if i <= input {print!("{} ", i)} else {break}
        i += 1;
    }

    print!("<==>");

    //membalik
    i = input;
    loop {
        if i >= 1 {print!(" {}", i)} else {break} 
        i -= 1
    }
    println!("\n");

    let data: [u32; 5] = [1000,2000,3000,4000,5000];
    i = 0;
    loop {
        println!("Element ke-{}: {}", i, data[i as usize]);
        i += 1;
        if i >= data.len() as i32 {break}
    }

    println!("\nProgram menghitung sisa bagi bilangan bulat");
    let a = getinput("Masukan nilai a: ");
    let b = getinput("masukan nilai b: ");

    let mut result = a;
    loop {
        if result >= b {result -= b} else {break}
    }
    println!("\nmodulus\t: {a} % {b} = {}", result);
    println!("bagi\t: {a} / {b} = {}.{}", a/b, (result*100)/b);
}

