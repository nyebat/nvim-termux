fn main() {
    // deklarasi tuple
    let my_tuple = ( 20, "hello", ['a', 'b'], 10.12345,);

    println!("{:?}", my_tuple);
    println!("{}", my_tuple.0);
    println!("{}", my_tuple.1);
    println!("{}", my_tuple.2[0]);
    println!("{}", my_tuple.2[1]);
    println!("{}\n", my_tuple.3);

    // menyimpan nilai tuple ke variable
    let ( nomor, kata, huruf, pecahan) = my_tuple;

    println!("{}", nomor);
    println!("{}", kata);
    println!("{} | {}", huruf[0], huruf[1]);
    println!("{}\n", pecahan);

    // membuat tuple mutable
    let mut my_tuple = ( 20, "hello", ['a', 'b'], 10.12345,);
    println!("{:?}\n", my_tuple);

    my_tuple.0 = 100;
    my_tuple.1 = "hello world!";
    println!("{:?}\n", my_tuple);

    // deklarasi tuple dengan nilai yg bersumber pada variabel lain
    let nomor = 123;
    let kata = "nama saya paijo";
    let buah = ["anggur", "melon", "salak"];

    let my_tuple = (nomor, kata, buah);
    println!("{:?}", my_tuple);

}
