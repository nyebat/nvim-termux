fn main() {
    // deklarasi vector
    let mut my_vector = vec![
        "apel",
        "melon",
        "salak",
        "mangga"
    ];
    println!("\n{:?}", my_vector);

    // menghitung elemen dan kapasitas vector
    println!("jumlah elemen: {} | size vector: {}\n", my_vector.len(), my_vector.capacity());

    // menghapus element vector
    my_vector.pop();
    println!("{:?}", my_vector);
    println!("jumlah elemen: {} | size vector: {}\n", my_vector.len(), my_vector.capacity());

    // menghapus elemen pada index tertentu
    my_vector.remove(1);
    println!("{:?}", my_vector);
    println!("jumlah elemen: {} | size vector: {}\n", my_vector.len(), my_vector.capacity());

    // menambahkan elemen kedalam vector
    my_vector.push("tomat");
    my_vector.push("sawi");
    my_vector.push("jagung");
    my_vector.push("cabai");
    println!("{:?}", my_vector);
    println!("jumlah elemen: {} | size vector: {}\n", my_vector.len(), my_vector.capacity());

    // check apakah vector memilik isi atau tidak
    println!("{}\n", my_vector.is_empty());

    // mengosongkan isi vector
    my_vector.clear();
    println!("{:?}", my_vector);
    println!("jumlah elemen: {} | size vector: {}\n", my_vector.len(), my_vector.capacity());

    // menggabungkan vector
    let mut vec_a = vec![1, 2, 3];
    let mut vec_b = vec![7, 8, 9];
    vec_a.append(&mut vec_b);

    println!("{:?}", vec_a);
    println!("jumlah elemen: {} | size vector: {}\n", vec_a.len(), vec_a.capacity());

    // menggabungkan vector inline
    vec_a.append(&mut vec![100, 200, 300]);
    println!("{:?}", vec_a);
    println!("jumlah elemen: {} | size vector: {}\n", vec_a.len(), vec_a.capacity());

    // mengurutkan elemen vector
    let mut vector = vec![3,8,9,1,6,2,5,7,4];
    println!("{:?}", vector);
    vector.sort();
    println!("{:?}\n", vector);

    /* macam macam cara mendeklarasikan vector
    * let mut vector_4 = vec![1, 2, 3];
    * let mut vector_5: Vec<i64> = vec![1, 2, 3];
    * let mut vector_7: Vec<&str> = vec![];
    * let mut vector_8: Vec<&str> = Vec::new();
    * */

    // Iterasi data vector
    my_vec();
}

//iterasi data vector
fn my_vec() {

    let vec_eight = vec![1, 2, 3];
    for e in vec_eight { print!("{e} "); };
    println!("\n");

    let vec_nine = vec![1, 2, 3];
    for i in 0..vec_nine.len() { print!("{} ", vec_nine[i]); };
    println!("\n");

    let vec_ten = vec![1, 2, 3];
    for e in &vec_ten { print!("{e} "); }
    for i in 0..vec_ten.len() { print!("{} ", vec_ten[i]); }

    for e in vec_ten.iter() { print!("{e} "); }
    println!("\n");

    let tuple = (3,4,5,6,7);
    let mut tuple_to_vec: Vec<i32> = Vec::new();

    for i in tuple.0..tuple.4 { tuple_to_vec.push(i); }
    println!("{:?}", tuple_to_vec);
}
