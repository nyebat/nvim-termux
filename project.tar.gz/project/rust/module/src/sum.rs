pub fn sum(value1: &f64, value2: &f64, flag: &str) -> f64 {
    let zero: f64 = 0.0;
    match flag {
        "+" => value1 + value2,
        "-" => value1 - value2,
        "*" => value1 * value2,
        "/" => {if value2 == &zero {return zero} else {value1 / value2}},
        _ => zero,
    }
}
