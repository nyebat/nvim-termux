use std::io::{self, Write};

pub fn get_alpha(msg: &str) -> String {
    print!("{}", msg);
    io::stdout().flush().expect("stdout Err");

    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("failed to read line");
    let output = input.trim().to_string();
    output
}

pub fn get_number(msg: String) -> f64 {
    let mut input: String = msg;

    loop { if let Ok(number) = input.parse::<f64>() {
        return number;
    } else {
        println!("Invalid input, please try again.");
        input = get_alpha("type a number: ");
    }}
}
