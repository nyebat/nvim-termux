use std::io::{self, Write};

fn main() {
    loop {
        let exit_code = hitung_string();
        if exit_code == 1 { break }
    }
}

fn hitung_string() -> i32 {
    // Meminta input dari pengguna
    print!("Masukkan kalimat Anda: ");
    io::stdout().flush().unwrap();

    let mut input_string = String::new();
    io::stdin().read_line(&mut input_string).expect("Gagal membaca baris");

    // Menghitung jumlah maksimal kata
    let words: Vec<&str> = input_string.split_whitespace().collect();
    let max_word_count = words.len();

    if max_word_count == 0 {
        println!("Tidak ada kata!");
        return 0;
    } else if input_string.trim() as &str == "q!" { return 1 }

    // Menampilkan informasi jumlah maksimal kata
    println!("Total kata: {}", max_word_count);

    // Meminta input pengguna untuk menampilkan kata ke berapa
    print!("Tampilkan kata ke (1-{}): ", max_word_count);
    io::stdout().flush().unwrap();

    let mut display_index = String::new();
    io::stdin().read_line(&mut display_index).expect("Gagal membaca baris");

    // Mengubah input menjadi bilangan bulat
    let display_index: usize = match display_index.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Input tidak valid. Aplikasi berhenti.");
            return 0;
        }
    };

    // Memeriksa apakah nomor berada dalam rentang yang benar
    if display_index - 1 >= max_word_count {
        println!("Nomor yang dimasukkan terlalu besar. Aplikasi berhenti.");
        return 0;
    }

    // Menampilkan kata sesuai input pengguna
    let displayed_word = words[display_index-1];
    println!("Kata ke-{}: {}",display_index, displayed_word);

    0
}


