// use std::fmt::Debug; // Debug berada pada std::fmt::Debug
// use std::any::type_name; //check of variabel type

use std::cmp::PartialOrd;
use std::fmt::Display;

// sekarang menambahkan Debug pada type Option cukup dengan menuliskannya T: Debug
// ini adalah fungsi denga type generic
fn return_type<T/* : Debug */>(value: T) -> T {
    value
}

// fungsi untuk cek type data
fn cek_type<T>(_: &T) -> &'static str {
    std::any::type_name::<T>()
}


fn compare_and_display<T: Display, U: Display + PartialOrd>(statement: T, num_1: U, num_2: U)
/* where
    T: Display,
    U: Display + PartialOrd, */
{
    println!("{}! Is {} greater than {}? {}", statement, num_1, num_2, num_1 > num_2);
}

fn main() {
    let i= return_type(4);
    println!("{} | {}", i, cek_type(&i));

    compare_and_display("Listen up!", 9, 8);
}

