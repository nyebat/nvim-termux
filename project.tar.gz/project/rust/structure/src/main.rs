/* Struct dan destructing */

// membuat struct Siswa dengan 3 fields
struct Siswa {
    nama: String, id: u32, kelas: &'static str,
}

// implementasi struct
impl Siswa {
    // asosiated diakses menggunakan (::) notation
    fn new(nama: String, id: u32, kelas: &'static str) -> Self {
        Self { nama, id, kelas }
    }

    // method diakses menggunakan (.) notation
    fn print(&self) {
        println!("nama siswa : {}", self.nama);
        println!("id siswa   : {}", self.id);
        println!("kelas      : {}\n", self.kelas);
    }
}

fn main() {
    // cara 1: membuat instansi struct
    let jono = Siswa {
        nama: String::from("Jono"), id: 112233, kelas: "9A", 
    };
    jono.print();

    // cara 2: membuat instansi menggunakan asosiated
    let jini = Siswa::new( 
        String::from("Jini"), 000111, "9A"
    );

    jini.print();

    // destructing atau menyimpan nilai field kedalam variabel
    let Siswa { nama: a, id: b, kelas: c, } = jono;
    println!("nama: {a} | {b} | {c}");

    let Siswa { nama: a, id: b, kelas: c, } = jini;
    println!("nama: {a} | {b} | {c}");
}
