// ARRAY
fn main() {
    // declarasi array
    let my_array: [&str; 5] = [
        "element1",
        "element2",
        "element3",
        "element4",
        "element5",
    ];

    // cetak array menggunakan for loop dengan index dan value
    for (index, element) in my_array.iter().enumerate() {
        println!("in for loop: {} | {}", index, element);
        if index == my_array.len() -1 { println!(); }
    }

    //declarasi array tanpa type
    let colors = ["red", "green", "blue", "yellow", "white"];
    // cetak array menggunakan while loop
    let mut index = 0;
    while index < colors.len() {
        println!("in while loop: {} | {}", index, colors[index]);

        index = index +1;
        if index >= my_array.len() { break }
    }

    println!(); index = 0;

    // declare array dengan nilai default
    let arr: [u8; 5] = [3; 5];
    // cetak array menggunakan loop
    loop {
        println!("in loop: {} | {}", index, arr[index]);

        index = index +1;
        if index >= arr.len() { break }
    }


    //akses nilai array menggunakan notasi [index]
    let arah = ["timur", "barat", "utara", "selatan"];
    println!("\n{}", arah[0]);
    println!("{}", arah[1]);
    println!("{}", arah[2]);
    println!("{}", arah[3]);

    for i in arah { println!("{i}") }
}

