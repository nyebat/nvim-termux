fn main() {
    let my_vec = vec![1,2,3,4,5];
    let cari = 5;

    println!("\nget: patern index menghasilkan Some(element)");
    if let Some(ok) = my_vec.get(cari) {
        println!("get is Some: index-{} is exist ({})", cari, ok);
    } else { println!("get is None: index-{} not found",cari); }

    println!("\nposision: patern element menghasilkan Some(indek)");
    if let Some(ok) = my_vec.iter().position(|&e| e == cari) {
        println!("element:{} ketemu pada index-{}", cari, ok);
    } else { println!("{} tidak ketemu", cari); }

    println!("\nfind: patern element menghasilkan Some(element)");
    match my_vec.iter().find(|&&i| i == cari) {
        Some(ok) => println!("{} ketemu", ok),
        None => println!("tidak ketemu"),
    }

    println!("\ncontains: patern element menghasilkan nilai bool");
    let contains = my_vec.contains(&cari);
    if contains {
        println!("{}", contains);
    } else { println!("{}", contains) }

    let some = if my_vec.get(cari).is_some() { *my_vec.get(cari).unwrap() } else{ 0 };
    println!("{:?}", some);
}
