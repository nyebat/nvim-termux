    const WHATS: bool = !true;

    fn main() {
        let life_or_void = |love: bool| -> &'static str {
            if love {
                "life"
            } else { "void" }
        };
        println!("your heart is: {:?}", life_or_void(WHATS));
    }
