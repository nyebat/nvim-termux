use std::io::{self, Write};
use std::fmt::Display;

fn get_input(msg: &str) -> String {
    print!("{}", msg);
    io::stdout().flush().unwrap();

    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read input");
    input.trim().to_string()
}

fn push_produk(produk: &mut Vec<String>, prompt: &str) {
    let add_element = get_input(&format!("{}Nama element : ", prompt));

    if !produk.contains(&add_element) {
        produk.push(add_element);
    } else {
        println!("Err! Element '{}' sudah ada!", add_element);
    }
}

fn remv_produk(produk: &mut Vec<String>, prompt: &str) {
    let rm_element = get_input(&format!("{}Nama element : ", prompt));

    if let Some(index) = produk.iter().position(|e| e == &rm_element) {
        produk.remove(index);
    }
    println!("Err! Element '{}' tidak ditemukan!", rm_element);
}

fn edit_produk(produk: &mut Vec<String>, prompt: &str) {
    let source = get_input(&format!("{}Source element : ", prompt));

    match produk.iter().position(|e| e == &source) {
        Some(index) => {
            let new_value = get_input(&format!("{}Change to : ", prompt));

            if produk.contains(&new_value) { 
                println!("Element dengan nama yg sama sudah ada!");
                return;
            }
            produk[index] = new_value;
            println!("Element '{}' edited to {}!", source, produk[index]);
        }
        None => {
            println!("Err! Element '{}' tidak ditemukan!", source);
        }
    }
}

fn print_produk_menu<T: Display>(produk: &Vec<T>) {
    println!();
    for (index, value) in produk.iter().enumerate() {
        println!("{index} | {value}")
    }
    println!();
}

fn print_editor_menu<T: Display>(editor: &Vec<T>) {
    for (i, v) in editor.iter().enumerate() {
        if i == 0 { print!("Editor: "); }
        print!("{v}");
        if i < editor.len() - 1 { print!(" | "); }
    }
}

fn add_list_produk() {
    let mut produk: Vec<String> = vec![
        "Kusen".into(), "Jendela".into(), "Pintu".into()
    ];
    let editor: Vec<&str> = vec![
        "[e]dit", "[p]ush", "[r]emove", "[q]uit"
    ];

    loop {
        print_produk_menu(&produk);
        print_editor_menu(&editor);

        let input = get_input("\n$~ : ");

        match input.to_lowercase().as_str() {
            "q" => break,
            "e" => edit_produk(&mut produk, "\n[e]dit > "),
            "p" => push_produk(&mut produk, "\n$ [P]ush > "),
            "r" => remv_produk(&mut produk, "\n$ [R]emove > "),
            _ => println!("Err! Input is invalid! '{}' Not found in the scope menu.", input),
        }
    }

    println!("\nTERIMA KASIH.");
}

fn main() {
    add_list_produk();
}

