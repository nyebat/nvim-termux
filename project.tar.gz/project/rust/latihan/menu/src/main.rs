
struct Produk {
    jumlah: u8,
}

impl Produk {
    fn new(jumlah:u8) -> Produk {
        Produk {jumlah}
    }

    fn show(&self) {
        println!("jumlah : {} buah", self.jumlah);
    }

    fn comparasi(&self, compare: u8) {
        println!("{}", self.jumlah == compare);
    }
}

fn main() {
    let jendela: Produk = Produk::new(8);
    jendela.show();

    jendela.comparasi(jendela.jumlah);

}
