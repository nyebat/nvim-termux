use std::io::{self, Write};

struct Size { size: u32, mount: String, index: u8, mg: String, }

impl Size { 
    fn new(size: u32, mount: String, index: u8, mg: String) -> Self { 
        Self { size, mount, index, mg } 
    } 
}

fn getinput(msg: &str) -> u32 {
    loop {
        print!("{msg}");
        io::stdout().flush().unwrap();

        let mut input = String::new();
        io::stdin().read_line(&mut input).expect("stdin Err");

        match input.trim().parse() {
            Ok(num) => return num,
            Err(_) => { println!("Input is invalid!"); continue; }
        }
    }
}

fn resize(mount: &mut Size, msg: &str, total_size: &mut u32) {
    if mount.size != 0 { 
        *total_size += mount.size;
        mount.size = 0;
    } else { 
        loop {
            let size = getinput(msg);
            if &size > total_size {
                println!("Err, Size is to larger!");
                continue;
            }
            mount.size = size; 
            *total_size -= mount.size;
            break;
        }
    }
}

fn main() {
    let mut total_size: u32 = 256;

    let mut boot = Size::new(0, format!("Boot"), 0, format!("GB"));
    let mut root = Size::new(0, format!("Root"), 0, format!("GB"));
    let mut swap = Size::new(0, format!("Swap"), 0, format!("GB"));
    let mut home = Size::new(0, format!("Home"), 0, format!("GB"));
    let mut free = Size::new(0, format!("Free"), 0, format!("GB"));

    let menu: Vec<&String> = vec![&boot.mount, &root.mount, &swap.mount, &home.mount, &free.mount];
    // let mut instances: Vec<&mut Size> = Vec::new();

    let mut iterasi: u8 = 1;
    for (i, v) in menu.iter().enumerate() {
        if i == 0 { println!("\nTotal Size: {}GB", total_size); }

        print!("[{}] {}\t\t", i +1, v);

        if iterasi == 3 { println!(); iterasi = 1; } else {iterasi+= 1}
        if i == menu.len() -1 { println!("[0] Save & Exit\n"); iterasi = 1 }
    }

    loop {

        let promp = getinput("Select: ");
        match promp {
            0 => { println!(); break },
            1 => resize(&mut boot, "Size boot: ", &mut total_size),
            2 => resize(&mut root, "Size root: ", &mut total_size),
            3 => resize(&mut swap, "Size swap: ", &mut total_size),
            4 => resize(&mut home, "Size home: ", &mut total_size),
            5 => resize(&mut free, "Size free: ", &mut total_size),
            _ => println!("Menu not found! Option range 1-5"),
        }

        let mut instances = vec![&mut boot, &mut root, &mut swap, &mut home, &mut free];
        iterasi = 1;
        let line: u8 = 62;

        for (i, v) in instances.iter().enumerate() {
            if i == 0 {
                if i == 0 { println!("\nTotal Size: {}GB", total_size); }
                for index in 0..=line { print!("="); if index == line { println!(); } }
            }

            match v.size > 0 {
                true => { print!("[{}] {}: {} ✓\t\t", i +1, v.mount, v.size); }
                false => { print!("[{}] {}\t\t", i +1, v.mount); }
            }

            match iterasi == 3 {
                true => { println!(); iterasi = 1; },
                false => iterasi += 1,
            }

            if i == instances.len() -1 { 
                println!("[0] Save & Exit"); 
                for i in 0..=line { print!("="); if i == line { println!("\n"); } }
            }
        }

        iterasi = 1;
        for i in 0..instances.len() {
            if instances[i].size > 0 {
                instances[i].index = iterasi;
                println!("[/dev/sda{}] {} {} {}", instances[i].index, instances[i].mount, instances[i].size, instances[i].mg);
                iterasi += 1
            }

            if i == instances.len() -1 { println!(); }
        }
    }
}
