/* ENUM STRUCT IMPL*/
enum DevOpsLanguage {
    Java, Kotlin, Rust
}

enum WebDevLanguage {
    Html, Css, Javascript
}

enum Dev {
    WebDev, DevOps
}
impl Dev {
    fn check(&self) {
        match self {
            Dev::WebDev => println!("Daftar Wedev"),
            Dev::DevOps => println!("Daftar Devops"),
        }
    }
}

struct LanguageMateri {
    basic: Vec<String>,
    course_price: u32,
    per_mounth: u8,
}

fn main() {
    let info = LanguageMateri {
        basic: vec![
            String::from("Variabel"),
            String::from("type data"),
            String::from("control flow"),
        ],
        course_price: 300,
        per_mounth: 16 
    };
}
