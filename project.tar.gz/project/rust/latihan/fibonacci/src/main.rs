fn main() {
    let start = 1;

    let (mut fn_, mut fn_1, mut fn_2);
    (fn_1, fn_2) = (0_u128, 1_u128);

    for iterasi in start..get_input() {

        // f(n) = f(n - 1) + f(n - 2)
        fn_ = fn_1 + fn_2;
        fn_1 = fn_2;
        fn_2 = fn_;

        if iterasi == start {println!("{} | {}", iterasi, fn_2)};
        println!("{} | {}", iterasi +1, fn_);
    }
}

fn get_input() -> u32 {
    use std::io::{self, Write};

    print!("Fibonacci: ");
    io::stdout().flush().unwrap();

    let mut input:String = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Err!")
    ;

    let input: u32 = match input.trim().parse() {
        Ok(num) => num,
        Err (_) => {
            println!("Input is invalid!");
            0
        }
    };

    input
}
